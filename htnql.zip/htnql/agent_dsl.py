from __future__ import annotations

from typing import Any, Dict, List

from .htn_core import Task, Method, PrimitiveOp
from .planning_state import PlanningState


def _get_field_value(state: PlanningState, field_path: str) -> Any:
    parts = field_path.split(".")
    value: Any = state
    for part in parts:
        if isinstance(value, dict):
            value = value.get(part)
        else:
            value = getattr(value, part, None)
    return value


def _eval_single_condition(state: PlanningState, cond: Dict[str, Any]) -> bool:
    field = cond.get("field")
    op = cond.get("op")
    expected = cond.get("value", None)
    actual = _get_field_value(state, field)

    if op == "eq":
        return actual == expected
    if op == "neq":
        return actual != expected
    if op == "is_null":
        return actual is None
    if op == "is_not_null":
        return actual is not None
    if op == "is_true":
        return bool(actual) is True
    if op == "is_false":
        return bool(actual) is False
    if op == "size_gte":
        try:
            return len(actual) >= int(expected)
        except Exception:
            return False
    if op == "size_lte":
        try:
            return len(actual) <= int(expected)
        except Exception:
            return False
    return False


def _eval_conditions(state: PlanningState, conds: List[Dict[str, Any]]) -> bool:
    return all(_eval_single_condition(state, c) for c in conds)


def build_methods_from_agent_config(agent_cfg: Dict[str, Any]) -> List[Method]:
    methods: List[Method] = []
    tasks_cfg = agent_cfg.get("tasks", {})

    for task_name, task_block in tasks_cfg.items():
        for method_cfg in task_block.get("methods", []):
            m_name = method_cfg.get("name", f"{task_name}_anon")
            conds = method_cfg.get("when", [])
            steps_cfg = method_cfg.get("steps", [])

            def make_condition(conds_snapshot):
                def _cond(state, task):
                    return _eval_conditions(state, conds_snapshot)
                return _cond

            def make_decompose(steps_snapshot):
                def _decompose(state, task):
                    subtasks: List[Task] = []
                    for step in steps_snapshot:
                        if "task" in step:
                            subtasks.append(Task(name=step["task"]))
                        elif "primitive" in step:
                            subtasks.append(Task(name=step["primitive"]))
                    return subtasks
                return _decompose

            methods.append(
                Method(
                    task_name=task_name,
                    condition=make_condition(conds),
                    decompose=make_decompose(steps_cfg),
                    name=m_name,
                )
            )

    return methods


def collect_primitives_for_agent(
    agent_cfg: Dict[str, Any],
    primitive_registry: Dict[str, PrimitiveOp],
) -> List[PrimitiveOp]:
    names: set[str] = set()
    tasks_cfg = agent_cfg.get("tasks", {})

    for task_name, task_block in tasks_cfg.items():
        for method_cfg in task_block.get("methods", []):
            for step in method_cfg.get("steps", []):
                prim_name = step.get("primitive")
                if prim_name:
                    names.add(prim_name)

    ops: List[PrimitiveOp] = []
    for name in names:
        op = primitive_registry.get(name)
        if op is not None:
            ops.append(op)
    return ops
