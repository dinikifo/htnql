"""Built-in planning agents for HTNQL v2."""

AGENTS_CONFIG = {
    "strict_joins": {
        "tasks": {
            "FindJoinForest": {
                "methods": [
                    {
                        "name": "StrictFK",
                        "when": [
                            {"field": "inferred_tables", "op": "size_gte", "value": 1},
                        ],
                        "steps": [
                            {"primitive": "FindJoinForest.StrictFK"},
                        ],
                    }
                ],
            },
            "BuildSqlFromPlan": {
                "methods": [
                    {
                        "name": "SqlAlchemyOnly",
                        "when": [],
                        "steps": [
                            {"primitive": "BuildSql.SqlAlchemy"},
                        ],
                    }
                ],
            },
        },
    },
    "heuristic_joins": {
        "tasks": {
            "FindJoinForest": {
                "methods": [
                    {
                        "name": "StrictFK",
                        "when": [
                            {"field": "inferred_tables", "op": "size_gte", "value": 1},
                        ],
                        "steps": [
                            {"primitive": "FindJoinForest.StrictFK"},
                        ],
                    },
                    {
                        "name": "HeuristicFallback",
                        "when": [],
                        "steps": [
                            {"primitive": "FindJoinForest.Heuristic"},
                        ],
                    },
                ],
            },
            "BuildSqlFromPlan": {
                "methods": [
                    {
                        "name": "SqlAlchemyPrimary",
                        "when": [],
                        "steps": [
                            {"primitive": "BuildSql.SqlAlchemy"},
                        ],
                    },
                    {
                        "name": "RawFallback",
                        "when": [
                            {"field": "scratch.allow_raw_fallback", "op": "is_true"},
                        ],
                        "steps": [
                            {"primitive": "BuildSql.Raw"},
                        ],
                    },
                ],
            },
        },
    },
}
