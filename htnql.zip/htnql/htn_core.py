"""htn_core.py - Minimal HTN planner for HTNQL v2."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple
import copy


@dataclass
class Task:
    name: str
    args: Tuple[Any, ...] = field(default_factory=tuple)
    kwargs: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Method:
    task_name: str
    condition: Callable[[Any, Task], bool]
    decompose: Callable[[Any, Task], List[Task]]
    name: str = ""


@dataclass
class PrimitiveOp:
    task_name: str
    apply: Callable[[Any, Task], Any]


@dataclass
class PlanStep:
    task: Task
    method_name: str


class PlanningFailure(Exception):
    """Raised when the planner cannot find a plan for a task."""
    pass


class HTNPlanner:
    """Depth-first HTN planner with simple backtracking."""

    def __init__(self, methods: List[Method], ops: List[PrimitiveOp]) -> None:
        self._methods_by_task: Dict[str, List[Method]] = {}
        for m in methods:
            self._methods_by_task.setdefault(m.task_name, []).append(m)
        self._ops_by_task: Dict[str, PrimitiveOp] = {op.task_name: op for op in ops}

    def plan_and_execute(self, state: Any, top_task: Task) -> Any:
        return self._execute_task(state, top_task)

    def _execute_task(self, state: Any, task: Task) -> Any:
        # 1) Primitive op?
        op = self._ops_by_task.get(task.name)
        if op is not None:
            new_state = op.apply(state, task)
            self._record_step(new_state, task, method_name="primitive")
            return new_state

        # 2) Compound task – try methods in order
        methods = self._methods_by_task.get(task.name, [])
        if not methods:
            raise PlanningFailure(f"No methods or primitive op for task {task.name!r}")

        last_error: Optional[Exception] = None

        for method in methods:
            try:
                if not method.condition(state, task):
                    continue
                branch_state = self._clone_state(state)
                subtasks = method.decompose(branch_state, task)
                for subtask in subtasks:
                    branch_state = self._execute_task(branch_state, subtask)
                self._record_step(branch_state, task, method_name=method.name or method.task_name)
                return branch_state
            except PlanningFailure as e:
                last_error = e
                continue

        if last_error is not None:
            raise last_error
        raise PlanningFailure(f"No applicable methods succeeded for task {task.name!r}")

    @staticmethod
    def _clone_state(state: Any) -> Any:
        # Shallow copy is enough for our PlanningState
        return copy.copy(state)

    @staticmethod
    def _record_step(state: Any, task: Task, method_name: str) -> None:
        if hasattr(state, "plan_trace"):
            trace = getattr(state, "plan_trace")
            if isinstance(trace, list):
                trace.append(PlanStep(task=task, method_name=method_name))
