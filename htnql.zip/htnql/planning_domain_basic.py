from __future__ import annotations

import re
from typing import List, Set

from .htn_core import Task, Method, PrimitiveOp, PlanningFailure
from .planning_state import PlanningState

TABLE_COL_RE = re.compile(r"([a-zA-Z_][\w]*)\.([a-zA-Z_][\w]*)")
MAX_TABLES = 6


def _split_table_column(s: str) -> tuple[str, str]:
    m = TABLE_COL_RE.fullmatch(s.strip())
    if not m:
        raise ValueError(f"Expected 'table.column' format, got: {s!r}")
    return m.group(1), m.group(2)


def build_basic_planning_domain() -> tuple[List[Method], List[PrimitiveOp]]:
    methods: List[Method] = []
    ops: List[PrimitiveOp] = []

    methods.append(METHOD_ANSWER_REPORT)
    methods.extend([
        METHOD_CHOOSE_MODE_RAW,
        METHOD_CHOOSE_MODE_BASE,
        METHOD_CHOOSE_MODE_AUTO,
    ])
    methods.extend([
        METHOD_PLAN_EXECUTION_RAW,
        METHOD_PLAN_EXECUTION_BASE,
        METHOD_PLAN_EXECUTION_AUTO,
    ])
    methods.append(METHOD_PLAN_AUTO_SQL)

    ops.extend([
        OP_PLAN_RAW_SQL,
        OP_PLAN_BASE_SQL,
        OP_VALIDATE_SPEC_STRUCTURALLY,
        OP_INFER_TABLES_FROM_SPEC,
        OP_ANALYZE_COMPLEXITY,
        OP_FIND_JOIN_FOREST,
        OP_BUILD_SQL_FROM_PLAN,
        OP_EXECUTE_PLANNED_SQL,
    ])

    return methods, ops


# AnswerReport
def _decompose_answer_report(state: PlanningState, task: Task):
    return [
        Task(name="ChooseExecutionMode"),
        Task(name="PlanExecution"),
        Task(name="ExecutePlannedSql"),
    ]


METHOD_ANSWER_REPORT = Method(
    task_name="AnswerReport",
    condition=lambda s, t: True,
    decompose=_decompose_answer_report,
    name="AnswerReport_default",
)


# ChooseExecutionMode
def _cond_raw_mode(state: PlanningState, task: Task) -> bool:
    return bool(state.spec.raw_sql)


def _decide_raw_mode(state: PlanningState, task: Task):
    state.execution_mode = "raw_sql"
    return []


METHOD_CHOOSE_MODE_RAW = Method(
    task_name="ChooseExecutionMode",
    condition=_cond_raw_mode,
    decompose=_decide_raw_mode,
    name="ChooseExecutionMode_raw_sql",
)


def _cond_base_mode(state: PlanningState, task: Task) -> bool:
    spec = state.spec
    return not spec.raw_sql and bool(spec.base_sql)


def _decide_base_mode(state: PlanningState, task: Task):
    state.execution_mode = "base_sql"
    return []


METHOD_CHOOSE_MODE_BASE = Method(
    task_name="ChooseExecutionMode",
    condition=_cond_base_mode,
    decompose=_decide_base_mode,
    name="ChooseExecutionMode_base_sql",
)


def _cond_auto_mode(state: PlanningState, task: Task) -> bool:
    spec = state.spec
    return not spec.raw_sql and not spec.base_sql


def _decide_auto_mode(state: PlanningState, task: Task):
    state.execution_mode = "auto"
    return []


METHOD_CHOOSE_MODE_AUTO = Method(
    task_name="ChooseExecutionMode",
    condition=_cond_auto_mode,
    decompose=_decide_auto_mode,
    name="ChooseExecutionMode_auto",
)


# PlanExecution
def _decompose_plan_execution_raw(state: PlanningState, task: Task):
    return [Task(name="PlanRawSql")]


METHOD_PLAN_EXECUTION_RAW = Method(
    task_name="PlanExecution",
    condition=lambda s, t: s.execution_mode == "raw_sql",
    decompose=_decompose_plan_execution_raw,
    name="PlanExecution_raw",
)


def _decompose_plan_execution_base(state: PlanningState, task: Task):
    return [Task(name="PlanBaseSql")]


METHOD_PLAN_EXECUTION_BASE = Method(
    task_name="PlanExecution",
    condition=lambda s, t: s.execution_mode == "base_sql",
    decompose=_decompose_plan_execution_base,
    name="PlanExecution_base",
)


def _decompose_plan_execution_auto(state: PlanningState, task: Task):
    return [Task(name="PlanAutoSql")]


METHOD_PLAN_EXECUTION_AUTO = Method(
    task_name="PlanExecution",
    condition=lambda s, t: s.execution_mode == "auto",
    decompose=_decompose_plan_execution_auto,
    name="PlanExecution_auto",
)


# PlanAutoSql pipeline
def _decompose_plan_auto_sql(state: PlanningState, task: Task):
    return [
        Task(name="ValidateSpecStructurally"),
        Task(name="InferTablesFromSpec"),
        Task(name="AnalyzeComplexity"),
        Task(name="FindJoinForest"),
        Task(name="BuildSqlFromPlan"),
    ]


METHOD_PLAN_AUTO_SQL = Method(
    task_name="PlanAutoSql",
    condition=lambda s, t: True,
    decompose=_decompose_plan_auto_sql,
    name="PlanAutoSql_pipeline",
)


# Primitives: validate / infer / complexity
def _apply_validate_spec_structurally(state: PlanningState, task: Task) -> PlanningState:
    spec = state.spec
    if not spec.metrics and not spec.group_by and not spec.filters:
        raise ValueError(
            "Invalid ReportSpec: no metrics, no group_by, no filters, "
            "and no SQL overrides (base_sql/raw_sql)."
        )
    for gb in spec.group_by:
        _split_table_column(gb)
    for f in spec.filters:
        if "." in f.column:
            _split_table_column(f.column)
    return state


OP_VALIDATE_SPEC_STRUCTURALLY = PrimitiveOp(
    task_name="ValidateSpecStructurally",
    apply=_apply_validate_spec_structurally,
)


def _apply_infer_tables_from_spec(state: PlanningState, task: Task) -> PlanningState:
    spec = state.spec
    tables: Set[str] = set()
    for gb in spec.group_by:
        t, _ = _split_table_column(gb)
        tables.add(t)
    for f in spec.filters:
        if "." in f.column:
            t, _ = _split_table_column(f.column)
            tables.add(t)
    for m in spec.metrics:
        for match in TABLE_COL_RE.finditer(m.expr):
            tables.add(match.group(1))
    if not tables:
        raise ValueError(
            "Auto-planned mode requires table-qualified references like 'table.column'. "
            "Use base_sql or raw_sql instead."
        )
    state.inferred_tables = tables
    return state


OP_INFER_TABLES_FROM_SPEC = PrimitiveOp(
    task_name="InferTablesFromSpec",
    apply=_apply_infer_tables_from_spec,
)


def _apply_analyze_complexity(state: PlanningState, task: Task) -> PlanningState:
    tables = state.inferred_tables or set()
    if len(tables) > MAX_TABLES:
        raise ValueError(
            f"Report involves {len(tables)} tables (> {MAX_TABLES}); "
            "too complex for auto-planning. Use base_sql or raw_sql."
        )
    return state


OP_ANALYZE_COMPLEXITY = PrimitiveOp(
    task_name="AnalyzeComplexity",
    apply=_apply_analyze_complexity,
)


# Plan raw/base
def _apply_plan_raw_sql(state: PlanningState, task: Task) -> PlanningState:
    raw_sql = state.spec.raw_sql
    if not raw_sql:
        raise PlanningFailure("PlanRawSql called, but spec.raw_sql is empty")
    state.sql_text = raw_sql
    return state


OP_PLAN_RAW_SQL = PrimitiveOp(
    task_name="PlanRawSql",
    apply=_apply_plan_raw_sql,
)


def _apply_plan_base_sql(state: PlanningState, task: Task) -> PlanningState:
    base_sql = state.spec.base_sql
    if not base_sql:
        raise PlanningFailure("PlanBaseSql called, but spec.base_sql is empty")
    state.sql_text = f"SELECT * FROM ({base_sql}) AS base"
    return state


OP_PLAN_BASE_SQL = PrimitiveOp(
    task_name="PlanBaseSql",
    apply=_apply_plan_base_sql,
)


# Default join forest (can be overridden by agents)
def _apply_find_join_forest(state: PlanningState, task: Task) -> PlanningState:
    try:
        forest = state.schema_graph.build_join_forest(state.inferred_tables)
    except Exception as e:
        raise PlanningFailure(f"Failed to build join forest: {e}") from e
    state.join_forest = forest
    return state


OP_FIND_JOIN_FOREST = PrimitiveOp(
    task_name="FindJoinForest",
    apply=_apply_find_join_forest,
)


def _apply_build_sql_from_plan(state: PlanningState, task: Task) -> PlanningState:
    # Agent primitives may already populate sql_ast/sql_text.
    if state.sql_ast is not None or state.sql_text:
        return state
    from .planning_primitives import _build_auto_sql_text  # type: ignore
    if not state.inferred_tables:
        raise PlanningFailure("BuildSqlFromPlan: inferred_tables is empty")
    if state.join_forest is None:
        raise PlanningFailure("BuildSqlFromPlan: join_forest is not set")
    sql = _build_auto_sql_text(
        spec=state.spec,
        tables=sorted(state.inferred_tables),
        join_forest=state.join_forest,
    )
    state.sql_text = sql
    return state


OP_BUILD_SQL_FROM_PLAN = PrimitiveOp(
    task_name="BuildSqlFromPlan",
    apply=_apply_build_sql_from_plan,
)


def _apply_execute_planned_sql(state: PlanningState, task: Task) -> PlanningState:
    from sqlalchemy import text as sa_text

    if getattr(state, "sql_ast", None) is not None:
        stmt = state.sql_ast
    elif state.sql_text:
        stmt = sa_text(state.sql_text)
    else:
        raise PlanningFailure("ExecutePlannedSql: neither sql_ast nor sql_text is set")

    with state.engine.connect() as conn:
        result = conn.execute(stmt)
        state.result_rows = [dict(row._mapping) for row in result]

    return state


OP_EXECUTE_PLANNED_SQL = PrimitiveOp(
    task_name="ExecutePlannedSql",
    apply=_apply_execute_planned_sql,
)
