from __future__ import annotations

from typing import Any, Dict, List

import sqlalchemy as sa
from sqlalchemy.sql import and_
from sqlalchemy import Table

from .htn_core import PrimitiveOp, PlanningFailure
from .planning_state import PlanningState
from .report_spec import ReportSpec
from .schema_graph import FKEdge
from .planning_domain_basic import _split_table_column


def _get_table(state: PlanningState, table_name: str) -> Table:
    metadata = getattr(state.schema_graph, "metadata", None)
    if metadata is None:
        raise PlanningFailure("SchemaGraph has no 'metadata' attribute for table resolution")
    try:
        return metadata.tables[table_name]
    except KeyError:
        raise PlanningFailure(f"Table {table_name!r} not found in metadata") from None


def _get_column(table_obj: Table, column_name: str):
    try:
        return table_obj.c[column_name]
    except KeyError:
        raise PlanningFailure(
            f"Column {column_name!r} not found on table {table_obj.name!r}"
        ) from None


def _infer_fk_on_clause(left: Table, right: Table):
    for fk in left.foreign_keys:
        if fk.column.table.name == right.name:
            return left.c[fk.parent.name] == fk.column
    for fk in right.foreign_keys:
        if fk.column.table.name == left.name:
            return right.c[fk.parent.name] == fk.column
    raise PlanningFailure(
        f"Cannot infer join condition between tables {left.name!r} and {right.name!r}"
    )


def _build_from_expr_sqlalchemy(
    state: PlanningState,
    tables: List[str],
    forest: List[FKEdge],
):
    if not tables:
        raise PlanningFailure("No tables available for FROM clause")

    table_map = {name: _get_table(state, name) for name in tables}
    root_name = sorted(table_map.keys())[0]
    from_expr = table_map[root_name]
    joined = {root_name}

    for edge in forest:
        a, b = edge.table_a, edge.table_b
        if a in joined and b not in joined:
            left_name, right_name = a, b
        elif b in joined and a not in joined:
            left_name, right_name = b, a
        else:
            continue

        left_tbl = table_map[left_name]
        right_tbl = table_map[right_name]
        onclause = _infer_fk_on_clause(left_tbl, right_tbl)
        from_expr = from_expr.join(right_tbl, onclause)
        joined.add(right_name)

    return from_expr, table_map


def _build_select_and_group_by_sqlalchemy(
    spec: ReportSpec,
    tables_map: Dict[str, Table],
):
    select_cols = []
    group_by_cols = []

    for ref in spec.group_by:
        tname, cname = _split_table_column(ref)
        if tname not in tables_map:
            raise PlanningFailure(f"Group-by references unknown table {tname!r}")
        col = _get_column(tables_map[tname], cname)
        select_cols.append(col.label(f"{tname}_{cname}"))
        group_by_cols.append(col)

    for m in spec.metrics:
        expr_text = m.expr.strip()
        if not expr_text:
            raise PlanningFailure("MetricSpec.expr must be non-empty")
        expr = sa.literal_column(expr_text)
        if m.alias:
            expr = expr.label(m.alias)
        select_cols.append(expr)

    if not select_cols:
        root_table = tables_map[sorted(tables_map.keys())[0]]
        select_cols = [root_table]

    return select_cols, group_by_cols


def _build_where_expression_sqlalchemy(
    spec: ReportSpec,
    tables_map: Dict[str, Table],
):
    clauses = []

    for f in spec.filters:
        if "." in f.column:
            tname, cname = _split_table_column(f.column)
            if tname not in tables_map:
                raise PlanningFailure(f"Filter references unknown table {tname!r}")
            col = _get_column(tables_map[tname], cname)
            op = f.op.upper()
            val = f.value
            if op == "=":
                clauses.append(col == val)
            elif op == "!=":
                clauses.append(col != val)
            elif op == ">":
                clauses.append(col > val)
            elif op == "<":
                clauses.append(col < val)
            elif op == ">=":
                clauses.append(col >= val)
            elif op == "<=":
                clauses.append(col <= val)
            elif op == "IN":
                clauses.append(col.in_(val))
            elif op == "LIKE":
                clauses.append(col.like(val))
            else:
                raise PlanningFailure(f"Unsupported filter operator: {f.op!r}")
        else:
            clauses.append(sa.text(f.column))

    if not clauses:
        return None
    return and_(*clauses)


def _apply_build_sql_sqlalchemy(state: PlanningState, task):
    spec = state.spec

    if not state.inferred_tables:
        raise PlanningFailure("BuildSql.SqlAlchemy: inferred_tables is empty")
    if state.join_forest is None:
        raise PlanningFailure("BuildSql.SqlAlchemy: join_forest is not set")

    tables = sorted(state.inferred_tables)
    from_expr, tables_map = _build_from_expr_sqlalchemy(state, tables, state.join_forest)
    select_cols, group_by_cols = _build_select_and_group_by_sqlalchemy(spec, tables_map)

    stmt = sa.select(*select_cols).select_from(from_expr)
    where_expr = _build_where_expression_sqlalchemy(spec, tables_map)
    if where_expr is not None:
        stmt = stmt.where(where_expr)
    if group_by_cols:
        stmt = stmt.group_by(*group_by_cols)
    if spec.limit is not None:
        stmt = stmt.limit(spec.limit)

    state.sql_ast = stmt
    try:
        compiled = stmt.compile(
            state.engine,
            compile_kwargs={"literal_binds": False},
        )
        state.sql_text = str(compiled)
    except Exception:
        state.sql_text = None

    return state


def _build_auto_sql_text(spec: ReportSpec, tables, join_forest) -> str:
    select_parts = []
    for ref in spec.group_by:
        select_parts.append(ref)
    for m in spec.metrics:
        expr = m.expr.strip()
        if m.alias:
            select_parts.append(f"{expr} AS {m.alias}")
        else:
            select_parts.append(expr)
    if not select_parts:
        select_clause = "SELECT *"
    else:
        select_clause = "SELECT " + ", ".join(select_parts)

    base_table = sorted(tables)[0]
    from_clause = f"FROM {base_table}"
    join_clauses = []
    for edge in getattr(join_forest, "edges", join_forest):
        join_clauses.append(f"-- JOIN {edge.table_b} ON fk({edge.table_a}, {edge.table_b})")
    from_and_joins = " ".join([from_clause] + join_clauses)

    where_clauses = []
    for f in spec.filters:
        where_clauses.append(f"{f.column} {f.op} {f.value!r}")
    where_clause = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""

    group_by_clause = "GROUP BY " + ", ".join(spec.group_by) if spec.group_by else ""
    limit_clause = f"LIMIT {int(spec.limit)}" if spec.limit is not None else ""

    parts = [select_clause, from_and_joins, where_clause, group_by_clause, limit_clause]
    return "\n".join(p for p in parts if p.strip())


def _apply_build_sql_raw(state: PlanningState, task):
    if not state.inferred_tables:
        raise PlanningFailure("BuildSql.Raw: no inferred tables")
    if state.join_forest is None:
        raise PlanningFailure("BuildSql.Raw: join_forest is not set")
    sql = _build_auto_sql_text(
        state.spec,
        sorted(state.inferred_tables),
        state.join_forest,
    )
    state.sql_text = sql
    return state


def _apply_find_join_forest_strict(state: PlanningState, task):
    try:
        forest = state.schema_graph.build_join_forest(state.inferred_tables)
    except Exception as e:
        raise PlanningFailure(f"Strict FK join planning failed: {e}") from e
    state.join_forest = forest
    return state


def _apply_find_join_forest_heuristic(state: PlanningState, task):
    return _apply_find_join_forest_strict(state, task)


PRIMITIVE_REGISTRY = {
    "FindJoinForest.StrictFK": PrimitiveOp(
        task_name="FindJoinForest.StrictFK",
        apply=_apply_find_join_forest_strict,
    ),
    "FindJoinForest.Heuristic": PrimitiveOp(
        task_name="FindJoinForest.Heuristic",
        apply=_apply_find_join_forest_heuristic,
    ),
    "BuildSql.SqlAlchemy": PrimitiveOp(
        task_name="BuildSql.SqlAlchemy",
        apply=_apply_build_sql_sqlalchemy,
    ),
    "BuildSql.Raw": PrimitiveOp(
        task_name="BuildSql.Raw",
        apply=_apply_build_sql_raw,
    ),
}
