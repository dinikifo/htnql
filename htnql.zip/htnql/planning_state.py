from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

from sqlalchemy.engine import Engine

from .schema_graph import SchemaGraph
from .report_spec import ReportSpec
from .htn_core import PlanStep


@dataclass
class PlanningState:
    """Mutable state passed through the HTN planner."""

    engine: Engine
    schema_graph: SchemaGraph
    spec: ReportSpec

    execution_mode: Optional[str] = None  # "raw_sql", "base_sql", "auto"

    inferred_tables: Set[str] = field(default_factory=set)
    join_forest: Any = None
    sql_ast: Any = None
    sql_text: Optional[str] = None

    result_rows: Optional[List[Dict[str, Any]]] = None

    plan_trace: List[PlanStep] = field(default_factory=list)
    scratch: Dict[str, Any] = field(default_factory=dict)
