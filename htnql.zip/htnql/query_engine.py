from __future__ import annotations

from typing import Any, Dict, List, Optional

from sqlalchemy.engine import Engine

from .schema_graph import SchemaGraph
from .report_spec import ReportSpec
from .planning_state import PlanningState
from .htn_core import HTNPlanner, Task
from .planning_domain_basic import build_basic_planning_domain
from .agent_dsl import build_methods_from_agent_config, collect_primitives_for_agent
from .planning_primitives import PRIMITIVE_REGISTRY
from .builtin_agents import AGENTS_CONFIG


class QueryEngine:
    """HTN-based query engine for HTNQL v2.

    This is largely backward compatible with the original engine:

    - You can still construct it as QueryEngine(engine, schema_graph)
      (the agent parameter is optional).
    - The old answer_report(spec) method is preserved as a thin wrapper
      around run_report(spec).
    """

    def __init__(
        self,
        engine: Engine,
        schema_graph: SchemaGraph,
        agent: str = "strict_joins",
        agents_config: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.engine = engine
        self.schema_graph = schema_graph

        if agents_config is None:
            agents_config = AGENTS_CONFIG
        if agent not in agents_config:
            raise ValueError(
                f"Unknown agent {agent!r}. Available agents: {', '.join(agents_config.keys())}"
            )

        self._agent_name = agent
        self._agents_config = agents_config

        base_methods, base_ops = build_basic_planning_domain()

        agent_cfg = agents_config[agent]
        agent_methods = build_methods_from_agent_config(agent_cfg)
        agent_ops = collect_primitives_for_agent(agent_cfg, PRIMITIVE_REGISTRY)

        methods = base_methods + agent_methods
        ops = base_ops + agent_ops

        self._planner = HTNPlanner(methods=methods, ops=ops)

    # New v2 API
    def run_report(self, spec: ReportSpec) -> List[Dict[str, Any]]:
        state = PlanningState(
            engine=self.engine,
            schema_graph=self.schema_graph,
            spec=spec,
        )
        final_state = self._planner.plan_and_execute(state, Task(name="AnswerReport"))
        return final_state.result_rows or []

    def run_report_with_trace(
        self, spec: ReportSpec
    ) -> tuple[List[Dict[str, Any]], List[Any]]:
        state = PlanningState(
            engine=self.engine,
            schema_graph=self.schema_graph,
            spec=spec,
        )
        final_state = self._planner.plan_and_execute(state, Task(name="AnswerReport"))
        return final_state.result_rows or [], final_state.plan_trace

    # Backwards-compatible alias for v1 demos
    def answer_report(self, spec: ReportSpec) -> List[Dict[str, Any]]:
        """Backward-compatible alias used by the original demos."""
        return self.run_report(spec)
