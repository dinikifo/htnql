from dataclasses import dataclass, field
from typing import Any, List, Optional


@dataclass
class MetricSpec:
    """
    Metric specification.

    expr:
        A SQL expression valid in a SELECT list in the target database.
        Example: "SUM(order_item.line_total)" or "avg(revenue)".
    alias:
        The output column name for this metric.
    """
    expr: str
    alias: str


@dataclass
class FilterSpec:
    """
    Simple filter predicate.

    column:
        In auto-planned mode: "table.column".
        In base_sql mode: a column name (or alias) from the base subquery.
    op:
        "=", "!=", "<", ">", "<=", ">=", "IN", "LIKE", etc.
    value:
        Literal or list of literals (for IN).
    """
    column: str
    op: str
    value: Any


@dataclass
class ReportSpec:
    """
    Declarative description of a report.

    Modes:
        1. raw_sql mode:
           - raw_sql is not None
           - The engine executes raw_sql directly.

        2. base_sql mode:
           - raw_sql is None and base_sql is not None
           - base_sql is treated as a subquery or full query.
           - You can optionally use metrics / group_by / filters on top.

        3. auto-planned mode:
           - raw_sql is None and base_sql is None
           - The engine inspects schema and builds joins automatically.
    """
    name: str

    # High-level declarative fields
    metrics: List[MetricSpec] = field(default_factory=list)
    group_by: List[str] = field(default_factory=list)
    filters: List[FilterSpec] = field(default_factory=list)
    limit: Optional[int] = None

    # SQL escape hatches
    base_sql: Optional[str] = None  # subquery or full query
    raw_sql: Optional[str] = None   # full query to execute directly

    # Internal fields used by the engine in auto mode
    tables: List[str] = field(default_factory=list, init=False)
    join_edges: List[str] = field(default_factory=list, init=False)  # engine-defined
