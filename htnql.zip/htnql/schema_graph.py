from dataclasses import dataclass
from typing import Dict, List, Set
from collections import defaultdict, deque

from sqlalchemy import MetaData


@dataclass
class FKEdge:
    """
    Undirected edge between two tables that are connected by at least one FK.
    We only track table names here; join conditions are inferred from metadata
    when building the actual SQL query.
    """
    table_a: str
    table_b: str


class SchemaGraph:
    """
    Lightweight graph over the database schema.

    Nodes: table names (metadata.tables keys)
    Edges: undirected edges between tables that have a FK relationship.
    """

    def __init__(self, metadata: MetaData):
        self.metadata = metadata
        self._adj: Dict[str, Set[str]] = defaultdict(set)
        self._build_graph()

    @classmethod
    def from_metadata(cls, metadata: MetaData) -> "SchemaGraph":
        return cls(metadata)

    def _build_graph(self) -> None:
        """
        Build an undirected adjacency list from SQLAlchemy metadata.
        """
        for table in self.metadata.tables.values():
            tname = table.name
            for fk in table.foreign_keys:
                ref_table = fk.column.table
                rname = ref_table.name
                self._adj[tname].add(rname)
                self._adj[rname].add(tname)

    def tables(self) -> List[str]:
        return list(self.metadata.tables.keys())

    def neighbors(self, table: str) -> Set[str]:
        return self._adj.get(table, set())

    def build_join_forest(self, needed_tables: Set[str]) -> List[FKEdge]:
        """
        For a given set of table names, return a list of FKEdge objects that
        connect them all, or raise ValueError if impossible.

        Uses a BFS over ONLY the needed tables. We do not include extra
        bridging tables here; if no path exists using only needed_tables,
        we treat the set as disconnected.
        """
        if not needed_tables:
            return []

        # pick an arbitrary start from the needed set
        start = next(iter(needed_tables))
        visited = {start}
        parent: Dict[str, str] = {}
        q = deque([start])

        remaining = set(needed_tables)
        remaining.discard(start)

        while q and remaining:
            cur = q.popleft()
            for nb in self.neighbors(cur):
                # only traverse neighbors that are part of the needed_tables set
                if nb not in needed_tables:
                    continue
                if nb not in visited:
                    visited.add(nb)
                    parent[nb] = cur
                    q.append(nb)
                    if nb in remaining:
                        remaining.remove(nb)

        if remaining:
            missing = ", ".join(sorted(remaining))
            raise ValueError(f"Tables not connected in schema graph: {missing}")

        forest: List[FKEdge] = []
        for child, par in parent.items():
            forest.append(FKEdge(par, child))

        return forest
