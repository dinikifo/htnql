from dataclasses import dataclass, field
from typing import Dict, List, Optional

from sqlalchemy import Integer, Numeric, Float, Date, DateTime

from .schema_graph import SchemaGraph


@dataclass
class ShapeIntent:
    description: str = ""
    focus_entities: List[str] = field(default_factory=list)
    time_grain: Optional[str] = None  # "day", "month", "year"
    metric_hints: List[str] = field(default_factory=list)
    include_tables: List[str] = field(default_factory=list)
    exclude_tables: List[str] = field(default_factory=list)


@dataclass
class ColumnRole:
    name: str
    table: str
    role: str  # "dimension" | "measure" | "time"
    note: str = ""


@dataclass
class CandidateShape:
    id: str
    description: str
    base_sql: str
    tables: List[str]
    columns: List[ColumnRole]
    confidence: float
    notes: Dict[str, str] = field(default_factory=dict)


def suggest_shapes(
    schema_graph: SchemaGraph,
    intent: ShapeIntent,
    max_suggestions: int = 5,
) -> List[CandidateShape]:
    md = schema_graph.metadata
    tables = list(md.tables.values())

    candidates = []
    for tbl in tables:
        if intent.include_tables and tbl.name not in intent.include_tables:
            continue
        if intent.exclude_tables and tbl.name in intent.exclude_tables:
            continue

        numeric_cols = sum(
            isinstance(c.type, (Integer, Numeric, Float)) for c in tbl.columns
        )
        fk_degree = len(tbl.foreign_keys)
        name_score = 0
        lname = tbl.name.lower()
        for token in intent.focus_entities + intent.metric_hints:
            if token.lower() in lname:
                name_score += 2

        score = numeric_cols + fk_degree + name_score
        candidates.append((score, tbl))

    if not candidates:
        return []

    candidates.sort(key=lambda x: x[0], reverse=True)
    shapes: List[CandidateShape] = []

    for idx, (_, fact_tbl) in enumerate(candidates[:max_suggestions]):
        fact_name = fact_tbl.name
        neighbor_names = sorted(schema_graph.neighbors(fact_name))
        used_tables = [fact_name] + neighbor_names

        join_clauses = []
        for nb in neighbor_names:
            left = md.tables[fact_name]
            right = md.tables[nb]
            on_sql = _infer_join_sql(left, right)
            if on_sql is None:
                continue
            join_clauses.append(f"JOIN {nb} ON {on_sql}")

        select_cols = []
        column_roles: List[ColumnRole] = []

        for tname in used_tables:
            tbl = md.tables[tname]
            for col in tbl.columns:
                col_name = f"{tname}.{col.name}"
                alias = f"{tname}_{col.name}"
                role = _infer_role(col.name, col.type)
                select_cols.append(f"{col_name} AS {alias}")
                column_roles.append(
                    ColumnRole(
                        name=alias,
                        table=tname,
                        role=role,
                    )
                )

        select_sql = ",\n    ".join(select_cols)
        join_sql = "\n    ".join(join_clauses)
        base_sql = f"""SELECT
    {select_sql}
FROM {fact_name}
    {join_sql}""".strip()

        confidence = min(1.0, (0.9 if idx == 0 else 0.5))

        shape = CandidateShape(
            id=f"{fact_name}_{idx}",
            description=f"Fact table '{fact_name}' joined with {', '.join(neighbor_names) or 'no neighbors'}",
            base_sql=base_sql,
            tables=used_tables,
            columns=column_roles,
            confidence=confidence,
        )
        shapes.append(shape)

    return shapes


def _infer_join_sql(left, right) -> Optional[str]:
    for fk in left.foreign_keys:
        if fk.column.table.name == right.name:
            return f"{left.name}.{fk.parent.name} = {right.name}.{fk.column.name}"
    for fk in right.foreign_keys:
        if fk.column.table.name == left.name:
            return f"{right.name}.{fk.parent.name} = {left.name}.{fk.column.name}"
    return None


def _infer_role(col_name: str, col_type) -> str:
    lname = col_name.lower()
    if "date" in lname or "month" in lname or isinstance(col_type, (Date, DateTime)):
        return "time"
    if isinstance(col_type, (Integer, Numeric, Float)):
        return "measure"
    return "dimension"
