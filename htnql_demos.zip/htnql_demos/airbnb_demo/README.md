# Airbnb-Style Bookings Demo

This demo creates a small **bookings & listings** database in `airbnb.db`
inspired by an Airbnb-style domain, for testing HTNQL and the GUI.

## Schema

Tables:
- `users` – hosts and guests (role, country)
- `listings` – properties with city, country, price_per_night, max_guests, property_type
- `bookings` – reservations with check-in/out dates, status, total_price_cents
- `reviews` – ratings and comments for completed stays

The schema is defined in **`airbnb_schema.sql`**.

## Populating data

From inside this folder, run:

```bash
python populate_airbnb_demo.py
```

This will:

1. Create `airbnb.db` with the schema (if it does not exist).
2. Insert a few hosts and guests.
3. Generate several listings per host across various cities.
4. Generate 20–40 bookings per listing over a ~3 month window, with random status.
5. Add reviews for a subset of confirmed bookings.

## Example queries to try in the GUI / HTNQL

- Host revenue by month (sum of `bookings.total_price_cents` grouped by host and month).
- Average rating per listing (join `reviews` and `listings`).
- Booking counts by city and property_type.
- Nights booked per listing in a date range (using check_in/check_out).
