PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id      INTEGER PRIMARY KEY,
    name    TEXT NOT NULL,
    email   TEXT NOT NULL UNIQUE,
    role    TEXT NOT NULL,      -- HOST, GUEST, BOTH
    country TEXT
);

CREATE TABLE IF NOT EXISTS listings (
    id                     INTEGER PRIMARY KEY,
    host_id                INTEGER NOT NULL REFERENCES users(id),
    title                  TEXT NOT NULL,
    city                   TEXT NOT NULL,
    country                TEXT NOT NULL,
    price_per_night_cents  INTEGER NOT NULL,
    max_guests             INTEGER NOT NULL,
    property_type          TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bookings (
    id                 INTEGER PRIMARY KEY,
    listing_id         INTEGER NOT NULL REFERENCES listings(id),
    guest_id           INTEGER NOT NULL REFERENCES users(id),
    check_in_date      TEXT NOT NULL,
    check_out_date     TEXT NOT NULL,
    status             TEXT NOT NULL,
    total_price_cents  INTEGER NOT NULL,
    created_at         TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reviews (
    id          INTEGER PRIMARY KEY,
    booking_id  INTEGER NOT NULL REFERENCES bookings(id),
    rating      INTEGER NOT NULL,
    comment     TEXT,
    created_at  TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_listings_host ON listings(host_id);
CREATE INDEX IF NOT EXISTS idx_bookings_listing ON bookings(listing_id);
CREATE INDEX IF NOT EXISTS idx_bookings_guest ON bookings(guest_id);
CREATE INDEX IF NOT EXISTS idx_bookings_created ON bookings(created_at);
CREATE INDEX IF NOT EXISTS idx_reviews_booking ON reviews(booking_id);
