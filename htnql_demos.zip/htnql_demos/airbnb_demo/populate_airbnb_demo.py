import sqlite3
from datetime import date, datetime, timedelta
import random
from pathlib import Path

DB_PATH = Path("airbnb.db")
SCHEMA_PATH = Path(__file__).parent / "airbnb_schema.sql"

CITIES = [
    ("Athens", "Greece"),
    ("Thessaloniki", "Greece"),
    ("Rome", "Italy"),
    ("Berlin", "Germany"),
    ("Paris", "France"),
]

PROPERTY_TYPES = ["ENTIRE_HOME", "PRIVATE_ROOM", "SHARED_ROOM"]


def create_schema(conn: sqlite3.Connection) -> None:
    sql = SCHEMA_PATH.read_text(encoding="utf-8")
    conn.executescript(sql)
    conn.commit()


def populate_demo_data(conn: sqlite3.Connection) -> None:
    random.seed(44)
    cur = conn.cursor()

    # Hosts
    hosts = [
        ("Host Alice", "host.alice@example.com", "HOST", "Greece"),
        ("Host Bob", "host.bob@example.com", "HOST", "Italy"),
        ("Host Carol", "host.carol@example.com", "HOST", "Germany"),
    ]
    conn.executemany(
        "INSERT OR IGNORE INTO users(name, email, role, country) VALUES (?, ?, ?, ?)",
        hosts,
    )

    # Guests
    guests = [
        ("Guest Zoe", "guest.zoe@example.com", "GUEST", "Greece"),
        ("Guest Nick", "guest.nick@example.com", "GUEST", "Italy"),
        ("Guest Maria", "guest.maria@example.com", "GUEST", "Germany"),
        ("Guest John", "guest.john@example.com", "GUEST", "France"),
        ("Guest Eva", "guest.eva@example.com", "GUEST", "Spain"),
    ]
    conn.executemany(
        "INSERT OR IGNORE INTO users(name, email, role, country) VALUES (?, ?, ?, ?)",
        guests,
    )
    conn.commit()

    cur.execute("SELECT id, email, role FROM users")
    users = cur.fetchall()
    host_ids = [u[0] for u in users if u[2] in ("HOST", "BOTH")]
    guest_ids = [u[0] for u in users if u[2] in ("GUEST", "BOTH")]

    # Listings
    listings = []
    for host_id in host_ids:
        for i in range(random.randint(2, 4)):
            city, country = random.choice(CITIES)
            base_price = random.randint(30, 150) * 100  # cents
            max_guests = random.randint(2, 6)
            ptype = random.choice(PROPERTY_TYPES)
            title = f"{city} {ptype.title().replace('_', ' ')} #{i+1}"
            listings.append(
                (host_id, title, city, country, base_price, max_guests, ptype)
            )

    conn.executemany(
        """
        INSERT INTO listings(host_id, title, city, country,
                             price_per_night_cents, max_guests, property_type)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        listings,
    )
    conn.commit()

    cur.execute("SELECT id, host_id, price_per_night_cents FROM listings")
    listings_rows = cur.fetchall()

    base_date = date(2025, 1, 1)
    bookings_inserted = []

    # Bookings
    for l_id, host_id, price_per_night in listings_rows:
        for _ in range(random.randint(20, 40)):
            created_day = base_date + timedelta(days=random.randint(0, 90))
            created_at = datetime.combine(
                created_day, datetime.min.time()
            ) + timedelta(hours=random.randint(8, 22))
            stay_start = created_day + timedelta(days=random.randint(1, 30))
            nights = random.randint(2, 7)
            stay_end = stay_start + timedelta(days=nights)

            status = random.choices(
                ["PENDING", "CONFIRMED", "CANCELLED"],
                weights=[1, 6, 2],
                k=1,
            )[0]

            guest_id = random.choice(guest_ids)
            base_total = price_per_night * nights
            total_price = int(base_total * random.uniform(0.9, 1.1))

            cur.execute(
                """
                INSERT INTO bookings(
                    listing_id, guest_id, check_in_date, check_out_date,
                    status, total_price_cents, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    l_id,
                    guest_id,
                    stay_start.isoformat(),
                    stay_end.isoformat(),
                    status,
                    total_price,
                    created_at.isoformat(timespec="seconds"),
                ),
            )
            booking_id = cur.lastrowid
            bookings_inserted.append((booking_id, status, stay_end))

    # Reviews
    for booking_id, status, stay_end in bookings_inserted:
        if status != "CONFIRMED":
            continue
        if random.random() < 0.7:  # 70% of confirmed stays get a review
            rating = random.choices([3, 4, 5], weights=[1, 3, 5], k=1)[0]
            review_date = datetime.combine(
                stay_end, datetime.min.time()
            ) + timedelta(
                days=random.randint(0, 5),
                hours=random.randint(8, 22),
            )
            comment = f"Review for booking {booking_id}, rating {rating}"
            cur.execute(
                """
                INSERT INTO reviews(booking_id, rating, comment, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (
                    booking_id,
                    rating,
                    comment,
                    review_date.isoformat(timespec="seconds"),
                ),
            )

    conn.commit()
    print("Airbnb-style demo data populated.")


def main():
    conn = sqlite3.connect(DB_PATH)
    try:
        create_schema(conn)
        populate_demo_data(conn)
    finally:
        conn.close()


if __name__ == "__main__":
    main()
