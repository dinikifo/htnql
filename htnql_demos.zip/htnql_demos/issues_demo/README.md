# Issue Tracker Demo

This demo creates a small **issue tracker** database in `issues.db`
suitable for testing HTNQL and the GUI.

## Schema

Tables:
- `projects` – projects like *Website*, *Mobile App*, *Backend API*
- `users` – people (reporters, assignees, comment authors)
- `issues` – core issues with type, status, priority, created/closed dates
- `issue_comments` – comments on issues
- `issue_labels` – labels/tags for issues (many-to-many)

The schema is defined in **`issues_schema.sql`**.

## Populating data

From inside this folder, run:

```bash
python populate_issues_demo.py
```

This will:

1. Create `issues.db` with the schema (if it does not exist).
2. Insert a few projects and users.
3. Insert about 120 issues over 60 days with random statuses, priorities, labels.
4. Add random comments to some issues.

## Example queries to try in the GUI / HTNQL

- Open issues by project and status.
- Issues created vs closed per week.
- Average time to close per project (`closed_at - created_at`).
- Issues by label and project (using `issue_labels`).
