PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS projects (
    id      INTEGER PRIMARY KEY,
    name    TEXT NOT NULL,
    key     TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS users (
    id      INTEGER PRIMARY KEY,
    name    TEXT NOT NULL,
    email   TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS issues (
    id           INTEGER PRIMARY KEY,
    project_id   INTEGER NOT NULL REFERENCES projects(id),
    title        TEXT NOT NULL,
    type         TEXT NOT NULL,
    status       TEXT NOT NULL,
    priority     TEXT NOT NULL,
    created_at   TEXT NOT NULL,
    closed_at    TEXT,
    assignee_id  INTEGER REFERENCES users(id),
    reporter_id  INTEGER REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS issue_comments (
    id         INTEGER PRIMARY KEY,
    issue_id   INTEGER NOT NULL REFERENCES issues(id),
    author_id  INTEGER NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL,
    body       TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS issue_labels (
    issue_id INTEGER NOT NULL REFERENCES issues(id),
    label    TEXT NOT NULL,
    PRIMARY KEY (issue_id, label)
);

CREATE INDEX IF NOT EXISTS idx_issues_project ON issues(project_id);
CREATE INDEX IF NOT EXISTS idx_issues_status ON issues(status);
CREATE INDEX IF NOT EXISTS idx_issues_assignee ON issues(assignee_id);
CREATE INDEX IF NOT EXISTS idx_issues_created ON issues(created_at);
