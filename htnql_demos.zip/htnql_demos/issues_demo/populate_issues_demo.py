import sqlite3
from datetime import datetime, timedelta
import random
from pathlib import Path

DB_PATH = Path("issues.db")
SCHEMA_PATH = Path(__file__).parent / "issues_schema.sql"

PROJECTS = [
    ("Website", "WEB"),
    ("Mobile App", "MOB"),
    ("Backend API", "API"),
]

USERS = [
    ("Alice", "alice@example.com"),
    ("Bob", "bob@example.com"),
    ("Carol", "carol@example.com"),
    ("Dave", "dave@example.com"),
]

TYPES = ["BUG", "TASK", "STORY"]
STATUSES = ["OPEN", "IN_PROGRESS", "DONE", "CANCELLED"]
PRIORITIES = ["LOW", "MEDIUM", "HIGH", "CRITICAL"]
LABELS = ["frontend", "backend", "api", "mobile", "performance", "ux", "security"]


def create_schema(conn: sqlite3.Connection) -> None:
    sql = SCHEMA_PATH.read_text(encoding="utf-8")
    conn.executescript(sql)
    conn.commit()


def populate_demo_data(conn: sqlite3.Connection) -> None:
    random.seed(43)
    cur = conn.cursor()

    conn.executemany(
        "INSERT OR IGNORE INTO projects(name, key) VALUES (?, ?)",
        PROJECTS,
    )
    conn.executemany(
        "INSERT OR IGNORE INTO users(name, email) VALUES (?, ?)",
        USERS,
    )
    conn.commit()

    cur.execute("SELECT id, key FROM projects")
    projects = cur.fetchall()
    cur.execute("SELECT id, name FROM users")
    users = cur.fetchall()

    base_date = datetime(2025, 1, 1)
    issue_counter = 1

    for day_offset in range(60):
        created_day = base_date + timedelta(days=day_offset)
        for _ in range(random.randint(0, 4)):
            project_id, project_key = random.choice(projects)
            typ = random.choice(TYPES)
            priority = random.choices(
                PRIORITIES, weights=[2, 4, 3, 1], k=1
            )[0]
            reporter_id, _ = random.choice(users)
            assignee_id, _ = random.choice(users)

            created_at = created_day + timedelta(
                hours=random.randint(8, 18),
                minutes=random.randint(0, 59),
            )
            status = random.choices(
                STATUSES,
                weights=[2, 3, 4, 1],
                k=1,
            )[0]

            if status in ("DONE", "CANCELLED"):
                closed_at = created_at + timedelta(days=random.randint(0, 10))
                closed_at_str = closed_at.isoformat(timespec="seconds")
            else:
                closed_at_str = None

            title = f"{project_key}-{issue_counter} {typ} issue"
            issue_counter += 1

            cur.execute(
                """
                INSERT INTO issues(
                    project_id, title, type, status, priority,
                    created_at, closed_at, assignee_id, reporter_id
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    project_id,
                    title,
                    typ,
                    status,
                    priority,
                    created_at.isoformat(timespec="seconds"),
                    closed_at_str,
                    assignee_id,
                    reporter_id,
                ),
            )
            iid = cur.lastrowid

            for label in random.sample(LABELS, k=random.randint(0, 3)):
                cur.execute(
                    "INSERT OR IGNORE INTO issue_labels(issue_id, label) VALUES (?, ?)",
                    (iid, label),
                )

            for _ in range(random.randint(0, 3)):
                author_id, _ = random.choice(users)
                comment_time = created_at + timedelta(
                    days=random.randint(0, 5),
                    hours=random.randint(0, 23),
                )
                body = f"Comment on issue {iid}"
                cur.execute(
                    """
                    INSERT INTO issue_comments(issue_id, author_id, created_at, body)
                    VALUES (?, ?, ?, ?)
                    """,
                    (iid, author_id, comment_time.isoformat(timespec="seconds"), body),
                )

    conn.commit()
    print("Issue tracker demo data populated.")


def main():
    conn = sqlite3.connect(DB_PATH)
    try:
        create_schema(conn)
        populate_demo_data(conn)
    finally:
        conn.close()


if __name__ == "__main__":
    main()
