# Ledger Demo (Double-Entry Accounting)

This demo creates a small **double-entry accounting** database in `ledger.db`
suitable for testing HTNQL and the GUI.

## Schema

Tables:
- `accounts` – chart of accounts (code, name, type: ASSET/LIABILITY/EQUITY/REVENUE/EXPENSE)
- `journals` – journals like *General Journal*, *Sales Journal*, *Cash Receipts*
- `transactions` – header rows (date, description, journal)
- `entries` – line items (account, amount_cents); each transaction balances (sum of amounts = 0)

The schema is defined in **`ledger_schema.sql`**.

## Populating data

From inside this folder, run:

```bash
python populate_ledger_demo.py
```

This will:

1. Create `ledger.db` with the schema (if it does not exist).
2. Insert a small chart of accounts.
3. Insert 60 days of sample transactions:
   - Opening equity
   - Sales on credit
   - Cash receipts
   - Random expenses

## Example queries to try in the GUI / HTNQL

- Trial balance: sum of `entries.amount_cents` by account.
- Income statement by month: revenue vs expense accounts grouped by month.
- General ledger for a single account (e.g. Cash or Sales Revenue).
