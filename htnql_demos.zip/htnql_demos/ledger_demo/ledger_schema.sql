PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS accounts (
    id      INTEGER PRIMARY KEY,
    code    TEXT NOT NULL UNIQUE,
    name    TEXT NOT NULL,
    type    TEXT NOT NULL CHECK (type IN ('ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE'))
);

CREATE TABLE IF NOT EXISTS journals (
    id      INTEGER PRIMARY KEY,
    name    TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS transactions (
    id          INTEGER PRIMARY KEY,
    journal_id  INTEGER NOT NULL REFERENCES journals(id),
    txn_date    TEXT NOT NULL,   -- ISO date YYYY-MM-DD
    description TEXT,
    ref         TEXT
);

CREATE TABLE IF NOT EXISTS entries (
    id             INTEGER PRIMARY KEY,
    transaction_id INTEGER NOT NULL REFERENCES transactions(id),
    account_id     INTEGER NOT NULL REFERENCES accounts(id),
    amount_cents   INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_entries_txn ON entries(transaction_id);
CREATE INDEX IF NOT EXISTS idx_entries_account ON entries(account_id);
CREATE INDEX IF NOT EXISTS idx_txn_date ON transactions(txn_date);
