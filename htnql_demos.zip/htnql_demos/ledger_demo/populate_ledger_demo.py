import sqlite3
from datetime import date, timedelta
import random
from pathlib import Path

DB_PATH = Path("ledger.db")
SCHEMA_PATH = Path(__file__).parent / "ledger_schema.sql"

ACCOUNTS = [
    ("1000", "Cash", "ASSET"),
    ("1100", "Bank", "ASSET"),
    ("1200", "Accounts Receivable", "ASSET"),
    ("2000", "Accounts Payable", "LIABILITY"),
    ("3000", "Owner Equity", "EQUITY"),
    ("4000", "Sales Revenue", "REVENUE"),
    ("4100", "Service Revenue", "REVENUE"),
    ("5000", "Cost of Goods Sold", "EXPENSE"),
    ("5100", "Rent Expense", "EXPENSE"),
    ("5200", "Utilities Expense", "EXPENSE"),
]


def create_schema(conn: sqlite3.Connection) -> None:
    sql = SCHEMA_PATH.read_text(encoding="utf-8")
    conn.executescript(sql)
    conn.commit()


def insert_accounts(conn: sqlite3.Connection) -> dict:
    conn.executemany(
        "INSERT OR IGNORE INTO accounts(code, name, type) VALUES (?, ?, ?)",
        ACCOUNTS,
    )
    conn.commit()
    cur = conn.execute("SELECT id, code FROM accounts")
    return {code: acc_id for acc_id, code in cur.fetchall()}


def insert_journals(conn: sqlite3.Connection) -> dict:
    names = ["General Journal", "Sales Journal", "Cash Receipts"]
    conn.executemany(
        "INSERT OR IGNORE INTO journals(name) VALUES (?)",
        [(n,) for n in names],
    )
    conn.commit()
    cur = conn.execute("SELECT id, name FROM journals")
    return {name: jid for jid, name in cur.fetchall()}


def insert_transaction(
    conn: sqlite3.Connection,
    journal_id: int,
    txn_date: date,
    description: str,
    ref: str,
    entries,  # list[(account_code, amount_cents)]
    account_ids: dict,
) -> None:
    total = sum(a for _, a in entries)
    if total != 0:
        raise ValueError(f"Unbalanced transaction: total={total}")

    cur = conn.cursor()
    cur.execute(
        "INSERT INTO transactions(journal_id, txn_date, description, ref) "
        "VALUES (?, ?, ?, ?)",
        (journal_id, txn_date.isoformat(), description, ref),
    )
    txn_id = cur.lastrowid

    for code, amount in entries:
        acc_id = account_ids[code]
        cur.execute(
            "INSERT INTO entries(transaction_id, account_id, amount_cents) "
            "VALUES (?, ?, ?)",
            (txn_id, acc_id, amount),
        )

    conn.commit()


def populate_demo_data(conn: sqlite3.Connection) -> None:
    random.seed(42)

    account_ids = insert_accounts(conn)
    journal_ids = insert_journals(conn)

    start = date(2025, 1, 1)
    days = 60

    # Opening equity
    insert_transaction(
        conn,
        journal_ids["General Journal"],
        start,
        "Owner investment",
        "CAP-001",
        [
            ("1000", 200_000_00),   # Cash +2,000.00
            ("3000", -200_000_00),  # Equity -2,000.00
        ],
        account_ids,
    )

    for i in range(1, days + 1):
        txn_date = start + timedelta(days=i)

        # 0–2 credit sales per day
        for _ in range(random.randint(0, 2)):
            amount = random.randint(100, 800) * 100  # cents
            cost = int(amount * random.uniform(0.4, 0.7))

            insert_transaction(
                conn,
                journal_ids["Sales Journal"],
                txn_date,
                "Invoice for customer",
                f"INV-{i:03d}-{random.randint(1,999):03d}",
                [
                    ("1200", amount),   # A/R
                    ("4000", -amount),  # Sales
                    ("5000", cost),     # COGS
                    ("1100", -cost),    # Bank (inventory proxy)
                ],
                account_ids,
            )

        # Customer payments
        if random.random() < 0.7:
            cash_amount = random.randint(50, 500) * 100
            insert_transaction(
                conn,
                journal_ids["Cash Receipts"],
                txn_date,
                "Customer payment",
                f"PMT-{i:03d}",
                [
                    ("1000", cash_amount),   # Cash +
                    ("1200", -cash_amount),  # AR -
                ],
                account_ids,
            )

        # Expenses
        if random.random() < 0.3:
            rent_amount = random.randint(50, 200) * 100
            insert_transaction(
                conn,
                journal_ids["General Journal"],
                txn_date,
                "Office expense",
                f"EXP-{i:03d}",
                [
                    ("5100", rent_amount),   # Rent expense
                    ("1000", -rent_amount),  # Cash
                ],
                account_ids,
            )

    print("Ledger demo data populated.")


def main():
    conn = sqlite3.connect(DB_PATH)
    try:
        create_schema(conn)
        populate_demo_data(conn)
    finally:
        conn.close()


if __name__ == "__main__":
    main()
